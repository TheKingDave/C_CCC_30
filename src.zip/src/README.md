This code was written with the help of 
[CCC_js_template](https://github.com/TheKingDave/CCC_js_template)