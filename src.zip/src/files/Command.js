export class Command {

    constructor(cmd, times) {
        this.cmd = cmd;
        this.times = Number(times);
    }


}